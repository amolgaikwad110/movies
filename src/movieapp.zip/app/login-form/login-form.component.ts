import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './../user.service';

@Component({
  selector: 'login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  constructor(private router : Router , private user : UserService) { }

  ngOnInit() {
  }

  loginUser(event){
    event.preventDefault();
    console.log(event);
    let userName = event.target.elements[0].value;
    let password = event.target.elements[1].value;
    console.log(userName , password);
    if(userName == "admin" && password == "admin"){
      this.user.setLoggedIn();
      this.router.navigate(['dashboard']);
    }
    return false;
  }
}
